export const TIPOS_NF_OPTIONS = [
    {value: "Revenda", label: "Revenda"},
    {value: "Despesa/Imobilizado", label: "Despesa/Imobilizado"},
    {value: "Materia Prima", label: "Materia Prima"},
    {value: "Collection", label: "Collection"},
    {value: "Garantia Concebida", label: "Garantia Concebida"},
];

export const PRIORIDADE_OPTIONS = [
    { value: "Alta", label: "Alta" },
    { value: "Media", label: "Média" },
    { value: "Baixa", label: "Baixa" },
]
