import { create } from "zustand";
import type { FornecedorOption } from "@inclusao/types";
import { usePreNotaStore } from "@inclusao/stores";

interface FornecedorState {
  options: FornecedorOption[];
  history: FornecedorOption[];
  isLoading: boolean;
  setOptions: (opts: FornecedorOption[]) => void;
  setLoading: () => void;
  clearLoading: () => void;
  pushToHistory: (option: FornecedorOption) => void;
  handleSelect: (cgc: string) => void;
}

export const useFornecedorStore = create<FornecedorState>((set, get) => ({
  options: [],
  history: [],
  isLoading: false,

  setOptions: (opts) => set({ options: opts }),

  setLoading: () => set({ isLoading: true }),
  clearLoading: () => set({ isLoading: false }),

  pushToHistory: (option) =>
    set((state) => ({
      history: [option, ...state.history.filter((h) => h.cnpj !== option.cnpj)].slice(0, 5),
    })),

  handleSelect: (cgc) => {
    const { options, history } = get();
    const selected = [...options, ...history].find((o) => o.cnpj === cgc);
    if (!selected) return;

    get().pushToHistory(selected);
    usePreNotaStore.getState().setHeader({
      FORNECEDOR: selected.cnpj,
      LOJA: selected.loja,
    });
  },
}));
