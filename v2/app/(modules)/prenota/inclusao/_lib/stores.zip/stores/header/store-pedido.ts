import { create } from "zustand";
import type { ProdutoPedido } from "@inclusao/types";
import type { PedidoResumo } from "@inclusao/types";

interface PedidosState {
  pedidos: PedidoResumo[];
  produtosPorPedido: Record<string, ProdutoPedido[]>;
  setPedidos: (pedidos: PedidoResumo[]) => void;
  setProdutos: (numero: string, produtos: ProdutoPedido[]) => void;
  clear: () => void;
}

export const usePedidosStore = create<PedidosState>((set) => ({
  pedidos: [],
  produtosPorPedido: {},
  setPedidos: (pedidos) => set({ pedidos }),
  setProdutos: (numero, produtos) => set((state) => ({ produtosPorPedido: { ...state.produtosPorPedido, [numero]: produtos } })),
  clear: () => set({ pedidos: [], produtosPorPedido: {} }),
}));