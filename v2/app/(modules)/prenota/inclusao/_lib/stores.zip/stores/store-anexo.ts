/* --------------------------------------------------------------------------
 *  _lib/stores/store-anexo.ts
 *  Pequeno store apenas para progresso de uploads de anexos
 * --------------------------------------------------------------------------*/
import { create } from "zustand";
import type { AnexoUploadState } from "@inclusao/types";

export const useAnexoUploadStore = create<AnexoUploadState>((set) => ({
  queue: [],

  addUpload: (seq: string, fileName: string) =>
    set((s) => ({ queue: [...s.queue, { seq, fileName, progress: 0 }] })),

  updateProgress: (seq, progress) =>
    set((s) => ({
      queue: s.queue.map((u) => (u.seq === seq ? { ...u, progress } : u))
    })),

  clearUpload: (seq) =>
    set((s) => ({ queue: s.queue.filter((u) => u.seq !== seq) }))
}));
