/* --------------------------------------------------------------------------
 *  _lib/stores/store-prenota.ts
 *  Zustand store principal do domínio Pré‑Nota
 * --------------------------------------------------------------------------*/
// _lib/stores/store-prenota.ts
import { create } from "zustand";
import type { PreNotaState } from "@inclusao/types";
import { preNotaInitial } from "@inclusao/types";

export const usePreNotaStore = create<PreNotaState>((set) => ({
  draft: { ...preNotaInitial },
  mode: "manual",

  /* Header */
  setHeader: (patch) =>
    set((s) => ({
      draft: { ...s.draft, header: { ...s.draft.header, ...patch } },
    })),
  setHeaderPatch: (patch) =>
    set((s) => ({
      draft: { ...s.draft, header: { ...s.draft.header, ...patch } },
    })),
  /**
   * Novo: define valor total da nota, para uso global
   */
  setHeaderTotal: (valor: number) =>
    set((s) => ({
      draft: {
        ...s.draft,
        header: { ...s.draft.header, valorTotalDaNota: valor },
      },
    })),

  /* Itens */
  setItens: (list) => set((s) => ({ draft: { ...s.draft, itens: list } })),
  addItem: (it) =>
    set((s) => ({ draft: { ...s.draft, itens: [...s.draft.itens, it] } })),
  updateItem: (idx, patch) =>
    set((s) => ({
      draft: {
        ...s.draft,
        itens: s.draft.itens.map((i, iIdx) => (iIdx === idx ? { ...i, ...patch } : i)),
      },
    })),
  removeItem: (idx) =>
    set((s) => ({
      draft: { ...s.draft, itens: s.draft.itens.filter((_, i) => i !== idx) },
    })),

  /* Anexos */
  addAnexo: (a) =>
    set((s) => ({ draft: { ...s.draft, anexos: [...s.draft.anexos, a] } })),
  removeAnexo: (seq) =>
    set((s) => ({
      draft: { ...s.draft, anexos: s.draft.anexos.filter((x) => x.seq !== seq) },
    })),

  /* Parcelas */
  setParcelas: (p) => set((s) => ({ draft: { ...s.draft, parcelas: p } })),

  /* Rateios */
  addRateio: (r) =>
    set((s) => ({ draft: { ...s.draft, rateios: [...s.draft.rateios, r] } })),
  updateRateio: (id, patch) =>
    set((s) => ({
      draft: {
        ...s.draft,
        rateios: s.draft.rateios.map((r) => (r.id === id ? { ...r, ...patch } : r)),
      },
    })),
  removeRateio: (id) =>
    set((s) => ({
      draft: { ...s.draft, rateios: s.draft.rateios.filter((r) => r.id !== id) },
    })),

  /* Modo */
  setModoXml: () => set({ mode: "xml" }),
  setModoManual: () => set({ mode: "manual" }),

  /* Reset */
  reset: () => set({ draft: { ...preNotaInitial }, mode: "manual" }),
}));