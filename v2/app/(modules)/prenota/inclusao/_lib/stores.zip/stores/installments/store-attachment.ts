// _lib/stores/header/useUploadsStore.ts
import { create } from "zustand";

export interface UploadFile {
  id: string;      // Identificador único gerado a partir do nome do arquivo + timestamp + índice
  file: File;
  name: string;
  size: number;
  url: string;
}

interface UploadsState {
  files: UploadFile[];
  addFiles: (files: FileList) => void;
  removeFile: (id: string) => void;
  clearAll: () => void;
}

export const useUploadsStore = create<UploadsState>((set) => ({
  files: [],

  addFiles: (fileList) => {
    const timestamp = Date.now();
    const newFiles: UploadFile[] = Array.from(fileList).map((file, idx) => ({
      id: `${file.name}-${timestamp}-${idx}`,
      file,
      name: file.name,
      size: file.size,
      url: URL.createObjectURL(file),
    }));
    set((state) => ({ files: [...state.files, ...newFiles] }));
  },

  removeFile: (id) => {
    set((state) => ({ files: state.files.filter((f) => f.id !== id) }));
  },

  clearAll: () => {
    set({ files: [] });
  },
}));
