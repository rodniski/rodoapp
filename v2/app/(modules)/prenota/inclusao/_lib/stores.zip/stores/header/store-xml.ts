import { create } from "zustand";
import type { CxnXmlDetails, XmlNormalized } from "@inclusao/types";

interface XmlState {
  chave: string | null;
  raw: CxnXmlDetails | null;
  headerPatch: XmlNormalized["headerPatch"] | null;
  itens: XmlNormalized["itens"];
  isLoading: boolean;
  error: string | null;
  setLoading: () => void;
  setSuccess: (chave: string, res: { raw: CxnXmlDetails; normalized: XmlNormalized }) => void;
  setError: (msg: string) => void;
}

export const useXmlStore = create<XmlState>((set) => ({
  chave: null,
  raw: null,
  headerPatch: null,
  itens: [],
  isLoading: false,
  error: null,
  setLoading: () => set({ isLoading: true, error: null }),
  setSuccess: (chave, { raw, normalized }) =>
    set({
      chave,
      raw,
      headerPatch: normalized.headerPatch,
      itens: normalized.itens,
      isLoading: false,
    }),
  setError: (msg) => set({ error: msg, isLoading: false }),
}));
