import { create } from "zustand";

type RateioItem = {
  id: string;
  seq: string;
  FIL: string;
  filial: string;
  cc: string;
  percent: number;
  valor: number;
  REC: number;
};

interface RateioState {
  rateios: RateioItem[];
  totalGeral: number;
  setTotalGeral: (total: number) => void;
  addRateio: (item: Omit<RateioItem, 'seq'>) => void;
  removeRateio: (id: string) => void;
  editRateio: (id: string, updated: Partial<RateioItem>) => void;
  clearRateios: () => void;
}

export const useRateioStore = create<RateioState>((set, get) => ({
  rateios: [],
  totalGeral: 0,
  setTotalGeral: (total) => set({ totalGeral: total }),
  addRateio: (item) => {
    set((state) => {
      const seq = String(state.rateios.length + 1).padStart(3, '0');
      const newRateio: RateioItem = { ...item, seq };
      return { rateios: [...state.rateios, newRateio] };
    });
  },
  removeRateio: (id) => set((state) => ({ rateios: state.rateios.filter(r => r.id !== id) })),
  editRateio: (id, updated) => set((state) => ({
    rateios: state.rateios.map(r => r.id === id ? { ...r, ...updated } : r)
  })),
  clearRateios: () => set({ rateios: [] }),
}));